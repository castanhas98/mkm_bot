# mkm_bot

A cardmarket.com bot to help updating card stock prices.

## Installation

## Using the bot

def main() -> None:
    print('Hello, World!')
    return


if __name__ == '__main__':
    main()

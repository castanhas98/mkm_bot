from .config import DataProviderConfig


class DataProvider:
    def DataProvider(config: DataProviderConfig) -> None:
        pass

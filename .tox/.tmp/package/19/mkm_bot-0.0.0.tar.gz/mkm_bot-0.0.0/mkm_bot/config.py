from dataclasses import dataclass


@dataclass
class DataProviderConfig:
    pass


@dataclass
class MkmBotConfig:
    pass
